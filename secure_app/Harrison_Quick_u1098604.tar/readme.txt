To use:

run bob.py with python3 command:
    CLI arguments aren't required, but some are offered:
    	-v, --verbose: to report events, values
	-p, --port:    specifies port (default 2100)

    bob.py acts like a server: it awaits a prompt from Alice asking for a key


next run alice.py with python3 command:
    CLI arguments aren't required, but some are offered:
    	-v  --verbose: to report events, values
	-p, --port:    specifies port (default 2100)
	    * Note that this must be the same port Bob is listening on, so if
	    * you specified a port for Bob, do it here too.
	    
	-i, --ip:      specifies the IP address of the machine Bob is running on
	    * Note: This is required unless bob.py is running on the same
	    * machine as alice.py
	    

So, for example, suppose you run bob.py on a machine with address 155.98.111.76:
    To do so, run:
		     $ python3 bob.py -p 2102

Then as long as alice.py is to be run on a machine with a different IP addres,
The -i and -p arguments must be specified as such:

       	             $ python3 alice.py -i 155.98.111.76 -p 2102

alice.py will prompt you from the command line once it is run to type in your message. bob.py will print the message once it is received and completely decrypted.
